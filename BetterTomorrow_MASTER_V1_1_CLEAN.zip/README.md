# Better Tomorrow — Android V1

Global English-first everyday utility app.

Current prototype:
- Home
- Search UI
- Nearby categories
- Daily wellness content
- Bottom navigation shell

Next build stages:
1. Live location and maps
2. Real place search
3. Hotel/booking integrations
4. Online content service
5. Multilingual support
6. Ads and premium monetization
7. Testing and Google Play release


Current Play Store preparation target:
- Target SDK: Android 16 / API 36.
- Internet and location permissions declared.
- Real Maps/Places, hotel booking, ads, privacy policy, signing, and production testing still require external account/service configuration.


Verified 2026-08-28: Places SDK for Android current documented dependency is 5.1.1; production requires a Google Cloud project, billing, enabled Places API, and securely configured API key. The app cannot embed the owner's secret API key in this source package.
