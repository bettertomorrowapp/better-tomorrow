package com.bettertomorrow.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;
import android.location.Location;
import android.location.LocationManager;

public class MainActivity extends Activity {
    private static final int LOCATION_REQUEST = 1001;
    private TextView status;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        status=findViewById(R.id.locationStatus);
        findViewById(R.id.locationButton).setOnClickListener(v->requestLocation());
        findViewById(R.id.shareButton).setOnClickListener(v->share());
        findViewById(R.id.mapButton).setOnClickListener(v->openMaps("nearby places"));
        bind(R.id.hotelButton,"hotels"); bind(R.id.foodButton,"restaurants");
        bind(R.id.schoolButton,"schools"); bind(R.id.hospitalButton,"hospitals");
        bind(R.id.shopButton,"shops"); bind(R.id.worshipButton,"places of worship");
    }
    private void bind(int id,String q){ findViewById(id).setOnClickListener(v->openMaps(q)); }
    private void requestLocation(){
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},LOCATION_REQUEST); return;
        }
        LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE); Location l=null;
        try{l=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER); if(l==null)l=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);}catch(Exception ignored){}
        status.setText(l==null?"📍 Location access is ready.":"📍 Location: "+String.format(java.util.Locale.US,"%.4f, %.4f",l.getLatitude(),l.getLongitude()));
    }
    private void openMaps(String q){
        Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("geo:0,0?q="+Uri.encode(q)));
        if(i.resolveActivity(getPackageManager())!=null)startActivity(i);
        else startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/maps/search/?api=1&query="+Uri.encode(q))));
    }
    private void share(){
        Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT,"Better Tomorrow 🌍 — Everything useful, every day.");
        startActivity(Intent.createChooser(i,"Share Better Tomorrow"));
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){
        super.onRequestPermissionsResult(r,p,g);
        if(r==LOCATION_REQUEST && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED) requestLocation();
        else if(r==LOCATION_REQUEST) Toast.makeText(this,"Location permission was not granted.",Toast.LENGTH_LONG).show();
    }
}
