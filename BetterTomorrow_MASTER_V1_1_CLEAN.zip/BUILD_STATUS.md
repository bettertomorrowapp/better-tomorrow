# Better Tomorrow — Build Status

The Android project source has been cleaned and the Gradle dependency block fixed.

Current:
- compileSdk 36
- targetSdk 36
- version 1.1.0
- Places SDK dependency declared
- Location/Internet permissions declared
- Nearby category and map actions implemented

Not compiled here:
- APK/AAB compilation requires an Android SDK/Gradle build environment.
- Release signing requires the owner's signing configuration.
- Production Maps/Places requires the owner's Google Cloud API key/billing.
- Play Store publishing requires the owner's Play Console account.

This file is the single master source project; do not create another project version just to repeat the same work.
