# Better Tomorrow V1 QA Checklist

[ ] App launches
[ ] Home screen renders correctly
[ ] Location permission request works
[ ] Location denied state is handled
[ ] Map button opens a map/search
[ ] Hotel/Food/School/Hospital/Shop/Worship actions open search
[ ] Share button opens Android share sheet
[ ] App works without location permission
[ ] No crash on rotation/relaunch
[ ] App label/icon are correct
[ ] Target API 36 is configured
[ ] Final privacy policy and data-safety declarations completed
[ ] Production Maps/Places credentials configured
[ ] Hotel/booking provider configured if included
[ ] AdMob configured and consent flow tested if monetized
[ ] Signed AAB generated
[ ] Internal/closed testing completed
