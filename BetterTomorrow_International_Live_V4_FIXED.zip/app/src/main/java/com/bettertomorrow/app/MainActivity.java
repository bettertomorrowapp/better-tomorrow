package com.bettertomorrow.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int LOCATION_REQUEST=1001;
    private TextView status;
    private final ExecutorService executor=Executors.newCachedThreadPool();
    private final Handler main=new Handler(Looper.getMainLooper());
    private double lat=4.1755, lon=73.5093; // Male fallback

    @Override public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        status=findViewById(R.id.locationStatus);
        findViewById(R.id.locationButton).setOnClickListener(v->requestLocation());
        findViewById(R.id.shareButton).setOnClickListener(v->shareApp());
        findViewById(R.id.currencyButton).setOnClickListener(v->showLive("💱 Currency Rates"));
        findViewById(R.id.newsButton).setOnClickListener(v->showLive("📰 World News"));
        findViewById(R.id.sportsButton).setOnClickListener(v->showLive("🏆 Sports"));
        findViewById(R.id.weatherButton).setOnClickListener(v->showLive("🌦️ Weather"));
        findViewById(R.id.countriesButton).setOnClickListener(v->showLive("🌎 Countries"));
        findViewById(R.id.travelButton).setOnClickListener(v->openWeb("https://www.google.com/search?q="+Uri.encode("official visa requirements travel country")));
        findViewById(R.id.placesButton).setOnClickListener(v->showLive("🏝️ Beautiful Places"));
        findViewById(R.id.alertsButton).setOnClickListener(v->showLive("🚨 World Alerts"));
        findViewById(R.id.pricesButton).setOnClickListener(v->openWeb("https://www.google.com/search?q="+Uri.encode("today fuel oil gas prices world")));
        findViewById(R.id.mapButton).setOnClickListener(v->openMaps("nearby places"));
    }

    private String get(String u) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();
        c.setConnectTimeout(10000); c.setReadTimeout(15000); c.setRequestProperty("User-Agent","BetterTomorrow/1.0");
        InputStream in=c.getResponseCode()<400?c.getInputStream():c.getErrorStream();
        BufferedReader r=new BufferedReader(new InputStreamReader(in)); StringBuilder s=new StringBuilder(); String line;
        while((line=r.readLine())!=null)s.append(line); r.close(); c.disconnect(); return s.toString();
    }
    private void showLive(String title){
        Toast.makeText(this,"Loading live information…",Toast.LENGTH_SHORT).show();
        executor.execute(()->{ String text;
            try {
                if(title.contains("Currency")) text=currency(); else if(title.contains("News")) text=news();
                else if(title.contains("Sports")) text=sports(); else if(title.contains("Weather")) text=weather();
                else if(title.contains("Countries")) text=countries(); else if(title.contains("Beautiful")) text=places(); else text=alerts();
            } catch(Exception e){text="Unable to load live data right now. Please check your internet connection and try again.";}
            final String out=text; main.post(()->new android.app.AlertDialog.Builder(this).setTitle(title).setMessage(out).setPositiveButton("OK",null).show());
        });
    }
    private String currency() throws Exception {
        JSONObject o=new JSONObject(get("https://api.frankfurter.app/latest?from=USD")); JSONObject r=o.getJSONObject("rates");
        String[] codes={"EUR","GBP","LKR","MVR","INR","JPY","AUD","CAD","SGD","AED"}; StringBuilder s=new StringBuilder("1 USD =\n");
        for(String x:codes) if(r.has(x)) s.append(x).append(" ").append(String.format(Locale.US,"%.4f",r.getDouble(x))).append("\n");
        s.append("\nUpdated: ").append(o.optString("date","today")); return s.toString();
    }
    private String weather() throws Exception {
        String u=String.format(Locale.US,"https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto",lat,lon);
        JSONObject o=new JSONObject(get(u)), c=o.getJSONObject("current"), d=o.getJSONObject("daily");
        return "Location: " + String.format(Locale.US,"%.3f, %.3f",lat,lon)+"\n\nNow: "+c.getDouble("temperature_2m")+"°C\nFeels: "+c.getDouble("apparent_temperature")+"°C\nHumidity: "+c.getInt("relative_humidity_2m")+"%\nWind: "+c.getDouble("wind_speed_10m")+" km/h\n\nTomorrow max: "+d.getJSONArray("temperature_2m_max").getDouble(1)+"°C\nTomorrow min: "+d.getJSONArray("temperature_2m_min").getDouble(1)+"°C\nRain chance: "+d.getJSONArray("precipitation_probability_max").getInt(1)+"%";
    }
    private String sports() throws Exception {
        JSONObject o=new JSONObject(get("https://site.api.espn.com/apis/site/v2/sports/cricket/8048/scoreboard")); JSONArray a=o.optJSONArray("events");
        if(a==null||a.length()==0) return "No current cricket events found.\n\nOther sports sections will be expanded in future updates.";
        StringBuilder s=new StringBuilder(); for(int i=0;i<Math.min(a.length(),8);i++){JSONObject e=a.getJSONObject(i); s.append("• ").append(e.optString("name","Match")).append("\n");} return s.toString();
    }
    private String news() throws Exception {
        String xml=get("https://news.google.com/rss?hl=en-US&gl=US&ceid=US:en"); StringBuilder s=new StringBuilder();
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("<item>(.*?)</item>",java.util.regex.Pattern.DOTALL).matcher(xml); int n=0;
        while(m.find()&&n<8){String item=m.group(1); java.util.regex.Matcher t=java.util.regex.Pattern.compile("<title>(.*?)</title>",java.util.regex.Pattern.DOTALL).matcher(item); if(t.find()){s.append("• ").append(android.text.Html.fromHtml(t.group(1)).toString().trim()).append("\n"); n++;}}
        return n==0?"No news available right now.":s.toString();
    }
    private String countries() throws Exception {
        JSONArray a=new JSONArray(get("https://restcountries.com/v3.1/all?fields=name,capital,currencies,population,region")); StringBuilder s=new StringBuilder("Examples from around the world:\n\n");
        String[] want={"Maldives","Sri Lanka","India","Japan","United Kingdom","France","Germany","Australia","United States"};
        for(String w:want) for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i); if(w.equalsIgnoreCase(x.getJSONObject("name").optString("common"))){s.append("• ").append(w).append(" — ").append(x.optString("region")).append(", population ").append(x.optLong("population")).append("\n");}}
        return s.toString();
    }
    private String places() throws Exception {
        String q=Uri.encode("world wonders beautiful places"); JSONObject o=new JSONObject(get("https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch="+q+"&gsrlimit=6&prop=extracts&exintro=1&explaintext=1&format=json&origin=*"));
        JSONObject pages=o.optJSONObject("query")==null?null:o.getJSONObject("query").optJSONObject("pages"); if(pages==null)return "Explore famous places around the world.\n\nTaj Mahal\nMaldives\nEiffel Tower\nGreat Barrier Reef\nSwiss Alps";
        StringBuilder s=new StringBuilder(); java.util.Iterator<String> it=pages.keys(); while(it.hasNext()){JSONObject p=pages.getJSONObject(it.next()); s.append("• ").append(p.optString("title")).append("\n");} return s.toString();
    }
    private String alerts() throws Exception {
        JSONObject o=new JSONObject(get("https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/significant_day.geojson")); JSONArray a=o.optJSONArray("features"); if(a==null||a.length()==0)return "No significant earthquakes reported in the latest USGS daily feed.";
        StringBuilder s=new StringBuilder("Significant earthquakes today:\n\n"); for(int i=0;i<a.length();i++){JSONObject p=a.getJSONObject(i).getJSONObject("properties"); s.append("• M").append(p.optDouble("mag",0)).append(" — ").append(p.optString("place")).append("\n");} return s.toString();
    }
    private void requestLocation(){if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},LOCATION_REQUEST);return;} LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE); Location loc=null; try{loc=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);if(loc==null)loc=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);}catch(SecurityException ignored){} if(loc!=null){lat=loc.getLatitude();lon=loc.getLongitude();status.setText("📍 Location ready: "+String.format(Locale.US,"%.4f, %.4f",lat,lon));}else status.setText("📍 Location permission is ready. Try Weather again.");}
    private void openMaps(String q){Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("geo:0,0?q="+Uri.encode(q)));if(i.resolveActivity(getPackageManager())!=null)startActivity(i);else openWeb("https://www.google.com/maps/search/?api=1&query="+Uri.encode(q));}
    private void openWeb(String u){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}
    private void shareApp(){Intent s=new Intent(Intent.ACTION_SEND);s.setType("text/plain");s.putExtra(Intent.EXTRA_TEXT,"Better Tomorrow 🌍 — Your world, in one place.");startActivity(Intent.createChooser(s,"Share Better Tomorrow"));}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==LOCATION_REQUEST){if(g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)requestLocation();else Toast.makeText(this,"Location permission is needed for weather features.",Toast.LENGTH_LONG).show();}}
    @Override protected void onDestroy(){executor.shutdownNow();super.onDestroy();}
}
