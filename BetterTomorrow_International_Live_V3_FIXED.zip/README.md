# Better Tomorrow — Android V1

Global English-first everyday utility app.

Current prototype:
- Home
- Search UI
- Nearby categories
- Daily wellness content
- Bottom navigation shell

Next build stages:
1. Live location and maps
2. Real place search
3. Hotel/booking integrations
4. Online content service
5. Multilingual support
6. Ads and premium monetization
7. Testing and Google Play release


Current Play Store preparation target:
- Target SDK: Android 16 / API 36.
- Internet and location permissions declared.
- Real Maps/Places, hotel booking, ads, privacy policy, signing, and production testing still require external account/service configuration.
